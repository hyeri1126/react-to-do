import { TODO_CATEGORY_ICON } from '@/constants/icon'
import { useState } from 'react'

const TodoForm = ({onClose, addTodo}) => {
    const [title, setTitle] = useState('')
    const [summary, setSummary] = useState('')
    const [category, setCategory] = useState('')
    
    const addTodoHandler = () => {
        onClose()
        addTodo({title, summary, category})
    }

    return (
        <>
                <h3 className="text-3xl text-red-200">Add Todo</h3>
                <form className='my-2'>
                    <div>
                        <label className='block mb-2 text-xl text-white' htmlFor='title'>Title</label>
                        <input className='w-full p-2 border-[1px] border-gray-300 bg-gray-200 text-gray-900 rounded' 
                            type='text' value={title} onChange={(e) => setTitle(e.target.value)} />
                    </div>
                    <div>
                        <label className='block mb-2 text-xl text-white' htmlFor='summary'>Summary</label>
                        <textarea className='w-full p-2 border-[1px] border-gray-300 bg-gray-200 text-gray-900 rounded' 
                                value={summary} rows='5' onChange={(e) => setSummary(e.target.value)} />
                    </div>
                    <div>
                        <label className='block mb-2 text-xl text-white' htmlFor='category'>Category</label>
                        <select className='w-full p-2 border-[1px] border-gray-300 bg-gray-200 text-gray-900 rounded' 
                                value={category}d onChange={(e) => setCategory(e.target.value)} >

                            <option value='TODO'>{TODO_CATEGORY_ICON.TODO} To do</option>
                            <option value='PROGRESS'>{TODO_CATEGORY_ICON.PROGRESS} On progress</option>
                            <option value='DONE'>{TODO_CATEGORY_ICON.DONE} Done</option>
                        </select>
                    </div>
                    {/* {isFormInValid && <div className='mt-2 text-red-500'>모든 항목을 채워서 작성해주세요</div>} */}
                    <div className='flex justify-end gap-4'>
                        <button onClick={onClose} className='text-xl text-white' type='button'>Cancel</button>
                        <button onClick={addTodoHandler} className='px-6 py-3 text-xl text-red-200' type='button'>Add</button>
                    </div>
                </form>
            </>
    )
    }

export default TodoForm